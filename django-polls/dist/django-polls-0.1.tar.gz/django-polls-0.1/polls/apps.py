from django.apps import AppConfig

# this is the config of your web applicaiton


class PollsConfig(AppConfig):
    name = 'polls'
